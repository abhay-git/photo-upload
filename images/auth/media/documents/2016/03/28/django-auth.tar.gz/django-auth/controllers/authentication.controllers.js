(function(){
  'use strict';

  angular
        .module('authentication.controllers')
        .controller('RegisterController',RegisterController)
        .directive('fileModel',fileModel);


        fileModel.$inject = ['$parse'];
        RegisterController.$inject = ['$location','$scope','$http','Authentication'];


        function RegisterController($location,$scope,$http,Authentication){
           
           var vm = this;

           vm.register = register

           function register() {
            alert(vm.email);

        $scope.option = {
              "email": vm.email,
              "username": vm.username,
              "password" : vm.password,
              "last_name" : vm.last_name,
              "file" : $scope.myFile
        };
        
        var formElement = document.querySelector('form');
        console.log(new FormData(formElement));
        var request = new XMLHttpRequest();
        request.open("POST",'http://127.0.0.1:8000/account/api/v1/accounts/');
        request.send(new FormData(formElement));

        //$http.post('http://127.0.0.1:8000/account/api/v1/accounts/',$scope.option).then(function(response){
          //console.log($scope.option);
          //alert("User Successfully register");
        //},function(error){
          //alert("fail");
        //})          
         }
        }
 
  })();

        function fileModel($parse){
          return {
            restrict :  'A',
            link : function(scope,element,attrs){
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change',function(){
                   scope.$apply(function(){
                      modelSetter(scope,element[0].files[0]);
                      //console.log(element[0].files[0]);
                   });
                });
            }
          };
        };