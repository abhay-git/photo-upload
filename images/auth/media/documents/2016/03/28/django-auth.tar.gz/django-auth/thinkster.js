(function(){
   'use strict'

   angular
         .module('thinkster',[
         	//'thinkster.config',
            'thinkster.routes',
            'thinkster.config',
            'thinkster.authentication'
         ]);

   angular
         .module('thinkster.routes',['ngRoute']);

   angular
         .module('thinkster.config',[]);


})();